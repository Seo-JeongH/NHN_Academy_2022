package com.nhnacademy.jdbc.board;

public interface Base {
}
