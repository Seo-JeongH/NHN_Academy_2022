package com.nhnacademy.springjpa.repository;

// marker interface
public interface RepositoryBase {
}
