package com.nhnacademy.springjpa.exception;

public class UserRegisterFailedException extends RuntimeException {
}
