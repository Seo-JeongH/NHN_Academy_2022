package com.nhnacademy.springjpa.controller;

// marker interface
public interface ControllerBase {
}
