package com.nhnacademy.springjpa;

public interface Base {
}
