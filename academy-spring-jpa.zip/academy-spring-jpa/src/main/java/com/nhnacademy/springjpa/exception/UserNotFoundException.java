package com.nhnacademy.springjpa.exception;

public class UserNotFoundException extends RuntimeException {
}
