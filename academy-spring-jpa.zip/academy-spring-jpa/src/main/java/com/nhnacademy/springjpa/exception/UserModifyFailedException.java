package com.nhnacademy.springjpa.exception;

public class UserModifyFailedException extends RuntimeException {
}
