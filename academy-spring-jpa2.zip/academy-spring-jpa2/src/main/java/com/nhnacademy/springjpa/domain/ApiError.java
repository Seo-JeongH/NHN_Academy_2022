package com.nhnacademy.springjpa.domain;

import lombok.Data;

@Data
public class ApiError {
    private String errorMessage;

}
