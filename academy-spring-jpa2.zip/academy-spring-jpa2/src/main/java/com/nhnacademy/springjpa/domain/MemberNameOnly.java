package com.nhnacademy.springjpa.domain;

public interface MemberNameOnly {
    String getUserName();

}
